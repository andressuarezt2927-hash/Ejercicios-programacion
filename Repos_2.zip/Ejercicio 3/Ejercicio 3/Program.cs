﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int estrato;
            decimal kw, impuesto_d = 0, s_kw = 0, t_kw = 0, precio = 0, precio_t, impuesto;

            Console.WriteLine("Ingrese el estrato del usuario (1 a 6):");
            decimal estratoDecimal = Convert.ToDecimal(Console.ReadLine());

            if (estratoDecimal < 1 || estratoDecimal > 6)
            {
                Console.WriteLine("Error: El estrato debe ser un número entre 1 y 6.");
            }
            else if (estratoDecimal % 1 != 0)
            {
                Console.WriteLine("Error: El estrato debe ser un valor entero (no se permiten decimales).");
            }
            else
            {
                estrato = (int)estratoDecimal;

                Console.WriteLine("Ingrese los Kw consumidos (pueden ser decimales):");
                kw = Convert.ToDecimal(Console.ReadLine());

                if (kw < 0)
                {
                    Console.WriteLine("Error: Los kilovatios no pueden ser un valor negativo.");
                }
                else
                {
                    if (kw <= 300)
                    {
                        t_kw = kw;
                        s_kw = 0;
                    }
                    else
                    {
                        t_kw = kw;
                        s_kw = kw - 300;
                        kw = kw - s_kw;
                    }
                    if (estrato == 1)
                    {
                        precio = (kw * 14m) + (s_kw * 17m);
                    }
                    else if (estrato == 2)
                    {
                        precio = (kw * 14m) + (s_kw * 17m);
                    }
                    else if (estrato == 3)
                    {
                        precio = (kw * 18m) + (s_kw * 23m);
                    }
                    else if (estrato == 4)
                    {
                        precio = (kw * 21m) + (s_kw * 27m);
                    }
                    else
                    {
                        precio = (kw * 28m) + (s_kw * 35m);
                    }
                    if (estrato == 1 || estrato == 2)
                    {
                        impuesto = 3m;
                        impuesto_d = precio * (impuesto / 100m);
                    }
                    else if (estrato == 3)
                    {
                        impuesto = 4m;
                        impuesto_d = precio * (impuesto / 100m);
                    }
                    else if (estrato == 4)
                    {
                        impuesto = 5m;
                        impuesto_d = precio * (impuesto / 100m);
                    }
                    else
                    {
                        impuesto = 6m;
                        impuesto_d = precio * (impuesto / 100m);
                    }
                    precio_t = precio + impuesto_d;
                    Console.WriteLine("\nEl costo de la factura por consumo de KW es: " + precio);
                    Console.WriteLine("El costo del impuesto es: " + impuesto_d);
                    Console.WriteLine("El valor total a pagar de la factura es: " + precio_t);
                }
            }
            Console.ReadKey();
        }
    }
}

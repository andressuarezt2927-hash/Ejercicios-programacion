﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            decimal h_slo;
            decimal total_v = 0;

            Console.WriteLine("Ingrese el valor que se le pagará al obrero por hora:");
            h_slo = Convert.ToDecimal(Console.ReadLine());

            if (h_slo <= 0)
            {
                Console.WriteLine("Error: La hora de salario tiene que ser mayor a 0.");
            }
            else
            {

                // DÍA 1
                decimal hour_t, hour_en, hour_sa, hour_ext;
                decimal increase_1, increase_2, valor, hexd, valor_t = 0, porc, hour_td;
                Console.WriteLine("Ingrese la hora de entrada EN FORMATO DE 24 HORAS (0 a 24) DIA 1:");
                hour_en = Convert.ToDecimal(Console.ReadLine());

                if (hour_en < 0 || hour_en > 24)
                {
                    Console.WriteLine("La hora no puede ser menor a 0 ni mayor a 24.");
                }
                else if (hour_en % 1 != 0)
                {
                    Console.WriteLine("No se permiten números decimales para la hora de entrada.");
                }
                else
                {
                    Console.WriteLine("Ingrese la hora de salida EN FORMATO DE 24 HORAS (0 a 24) DIA 1:");
                    hour_sa = Convert.ToDecimal(Console.ReadLine());

                    if (hour_sa < 0 || hour_sa > 24)
                    {
                        Console.WriteLine("La hora no puede ser menor a 0 ni mayor a 24.");
                    }
                    else if (hour_sa % 1 != 0)
                    {
                        Console.WriteLine("No se permiten números decimales para la hora de salida.");
                    }
                    else
                    {
                        // Calcular las horas trabajadas 
                        hour_t = Math.Abs(hour_en - hour_sa);

                        if (hour_t > 8)
                        {
                            hour_ext = hour_t - 8;
                            hexd = hour_ext;
                            increase_1 = hexd * (h_slo * (50m / 100m));
                            valor_t = increase_1 + (8 * h_slo) + (hour_ext * h_slo);
                        }
                        if (hour_t < 6)
                        {
                            hour_td = hour_t;
                            valor = hour_td * h_slo;
                            porc = 10m / 100m;
                            increase_2 = valor * porc;
                            valor_t = valor + increase_2;
                        }
                        if (hour_t < 4)
                        {
                            valor_t = 0;
                        }
                        if (hour_t >= 4 && hour_t < 5)
                        {
                            valor_t = hour_t * h_slo;
                        }
                        if (hour_t >= 6 || hour_t == 8)
                        {
                            valor_t = hour_t * h_slo;
                        }

                        // DÍA 2
                        decimal hour_t2, hour_en2, hour_sa2, hour_ext2;
                        decimal increase_3, increase_4, valor2, hexd2, valor_t2 = 0, porc2, hour_td2;
                        Console.WriteLine("Ingrese la hora de entrada del DIA 2 EN FORMATO DE 24 HORAS (0 a 24):");
                        hour_en2 = Convert.ToDecimal(Console.ReadLine());

                        if (hour_en2 < 0 || hour_en2 > 24)
                        {
                            Console.WriteLine("La hora no puede ser menor a 0 ni mayor a 24.");
                        }
                        else if (hour_en2 % 1 != 0)
                        {
                            Console.WriteLine("No se permiten números decimales para la hora de entrada.");
                        }
                        else
                        {
                            Console.WriteLine("Ingrese la hora de salida (Día 2) EN FORMATO DE 24 HORAS (0 a 24):");
                            hour_sa2 = Convert.ToDecimal(Console.ReadLine());

                            if (hour_sa2 < 0 || hour_sa2 > 24)
                            {
                                Console.WriteLine("Error: La hora no puede ser menor a 0 ni mayor a 24.");
                            }
                            else if (hour_sa2 % 1 != 0)
                            {
                                Console.WriteLine("Error: No se permiten números decimales para la hora de salida.");
                            }
                            else
                            {
                                // Calcular las horas trabajadas 
                                hour_t2 = Math.Abs(hour_en2 - hour_sa2);

                                if (hour_t2 > 8)
                                {
                                    hour_ext2 = hour_t2 - 8;
                                    hexd2 = hour_ext2;
                                    increase_3 = hexd2 * (h_slo * (50m / 100m));
                                    valor_t2 = increase_3 + (8 * h_slo)  + (hour_ext2 * h_slo);
                                }
                                if (hour_t2 < 6)
                                {
                                    hour_td2 = hour_t2;
                                    valor2 = hour_td2 * h_slo;
                                    porc2 = 10m / 100m;
                                    increase_4 = valor2 * porc2;
                                    valor_t2 = valor2 + increase_4;
                                }
                                if (hour_t2 < 4)
                                {
                                    valor_t2 = 0;
                                }
                                if (hour_t2 >= 4 && hour_t2 < 5)
                                {
                                    valor_t2 = hour_t2 * h_slo;
                                }
                                if (hour_t2 >= 6 || hour_t2 == 8)
                                {
                                    valor_t2 = hour_t2 * h_slo;
                                }

                                // DÍA 3
                                decimal hour_t3, hour_en3, hour_sa3, hour_ext3;
                                decimal increase_5, increase_6, valor3, hexd3, valor_t3 = 0, porc3, hour_td3;
                                Console.WriteLine("Ingrese la hora de entrada (Día 3) EN FORMATO DE 24 HORAS (0 a 24):");
                                hour_en3 = Convert.ToDecimal(Console.ReadLine());

                                if (hour_en3 < 0 || hour_en3 > 24)
                                {
                                    Console.WriteLine("La hora no puede ser menor a 0 ni mayor a 24.");
                                }
                                else if (hour_en3 % 1 != 0)
                                {
                                    Console.WriteLine("No se permiten números decimales para la hora de entrada.");
                                }
                                else
                                {
                                    Console.WriteLine("Ingrese la hora de salida (Día 3) EN FORMATO DE 24 HORAS (0 a 24):");
                                    hour_sa3 = Convert.ToDecimal(Console.ReadLine());

                                    if (hour_sa3 < 0 || hour_sa3 > 24)
                                    {
                                        Console.WriteLine("La hora no puede ser menor a 0 ni mayor a 24.");
                                    }
                                    else if (hour_sa3 % 1 != 0)
                                    {
                                        Console.WriteLine("No se permiten números decimales para la hora de salida.");
                                    }
                                    else
                                    {
                                        // Calcular las horas trabajadas 
                                        hour_t3 = Math.Abs(hour_en3 - hour_sa3);

                                        if (hour_t3 > 8)
                                        {
                                            hour_ext3 = hour_t3 - 8;
                                            hexd3 = hour_ext3;
                                            increase_5 = hexd3 * (h_slo * (50m / 100m));
                                            valor_t3 = increase_5 + (8 * h_slo) + (hour_ext3 * h_slo);
                                        }
                                        if (hour_t3 < 6)
                                        {
                                            hour_td3 = hour_t3;
                                            valor3 = hour_td3 * h_slo;
                                            porc3 = 10m / 100m;
                                            increase_6 = valor3 * porc3;
                                            valor_t3 = valor3 + increase_6;
                                        }
                                        if (hour_t3 < 4)
                                        {
                                            valor_t3 = 0;
                                        }
                                        if (hour_t3 >= 4 && hour_t3 < 5)
                                        {
                                            valor_t3 = hour_t3 * h_slo;
                                        }
                                        if (hour_t3 >= 6 || hour_t3 == 8)
                                        {
                                            valor_t3 = hour_t3 * h_slo;
                                        }

                                        //Calcular el Total
                                        total_v = valor_t + valor_t2 + valor_t3;
                                        Console.Write("El salario total para el obrero es: " + total_v);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
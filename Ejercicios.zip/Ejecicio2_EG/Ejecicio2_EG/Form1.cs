﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejecicio2_EG
{
   
    public partial class Background : Form
    {
        int diaActual = 1;
        decimal vh = 0;
        int ht1 = 0, ht2 = 0, ht3 = 0;
        decimal pagoDia1 = 0, pagoDia2 = 0, pagoDia3 = 0;

        public Background()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void seg_Click(object sender, EventArgs e)
        {
            if (diaActual == 1)
            {
                bool error = false;
                int he1 = 0, hs1 = 0;

                if (!decimal.TryParse(valorhora_tb.Text, out vh) || vh <= 0)
                {
                    error = true;
                    MessageBox.Show("Ingrese un valor de hora válido mayor a 0");
                }
                if (!int.TryParse(horaen_tb.Text, out he1) || he1 < 0 || he1 > 24)
                {
                    error = true;
                    MessageBox.Show("Para la hora de entrada ingrese valores enteros de 0 a 24");
                }
                if (!int.TryParse(horasal_tb.Text, out hs1) || hs1 < 0 || hs1 > 24)
                {
                    error = true;
                    MessageBox.Show("Para la hora de salida ingrese valores enteros de 0 a 24");
                }

                if (!error)
                {
                    ht1 = Math.Abs(hs1 - he1);

                    if (ht1 < 4)
                    {
                        pagoDia1 = 0;
                    }
                    else if (ht1 < 6)
                    {
                        pagoDia1 = (ht1 * vh) * 0.90m;
                    }
                    else if (ht1 <= 8)
                    {
                        pagoDia1 = ht1 * vh;
                    }
                    else
                    {
                        int extras = ht1 - 8;
                        pagoDia1 = (8 * vh) + (extras * vh * 1.5m);
                    }

                    valorhora_tb.ReadOnly = true;

                    day_t.Text = "Dia 2";
                    hoursa_l.Text = "Hora de salida (Dia 2) :";
                    houren_l.Text = "Hora de entrada (Dia 2) :";
                    horaen_tb.Text = "";
                    horasal_tb.Text = "";

                    diaActual = 2;
                }
            }
            else if (diaActual == 2)
            {
                bool error2 = false;
                int he2 = 0, hs2 = 0;

                if (!int.TryParse(horaen_tb.Text, out he2) || he2 < 0 || he2 > 24)
                {
                    error2 = true;
                    MessageBox.Show("Para la hora de entrada ingrese valores enteros de 0 a 24");
                }
                if (!int.TryParse(horasal_tb.Text, out hs2) || hs2 < 0 || hs2 > 24)
                {
                    error2 = true;
                    MessageBox.Show("Para la hora de salida ingrese valores enteros de 0 a 24");
                }

                if (!error2)
                {
                    ht2 = Math.Abs(hs2 - he2);

                    if (ht2 < 4)
                    {
                        pagoDia2 = 0;
                    }
                    else if (ht2 < 6)
                    {
                        pagoDia2 = (ht2 * vh) * 0.90m;
                    }
                    else if (ht2 <= 8)
                    {
                        pagoDia2 = ht2 * vh;
                    }
                    else
                    {
                        int extras = ht2 - 8;
                        pagoDia2 = (8 * vh) + (extras * vh * 1.5m);
                    }

                    day_t.Text = "Dia 3";
                    hoursa_l.Text = "Hora de salida (Dia 3) :";
                    houren_l.Text = "Hora de entrada (Dia 3) :";
                    horaen_tb.Text = "";
                    horasal_tb.Text = "";

                    diaActual = 3;
                }
            }
            else if (diaActual == 3)
            {
                bool error3 = false;
                int he3 = 0, hs3 = 0;

                if (!int.TryParse(horaen_tb.Text, out he3) || he3 < 0 || he3 > 24)
                {
                    error3 = true;
                    MessageBox.Show("Para la hora de entrada ingrese valores enteros de 0 a 24");
                }
                if (!int.TryParse(horasal_tb.Text, out hs3) || hs3 < 0 || hs3 > 24)
                {
                    error3 = true;
                    MessageBox.Show("Para la hora de salida ingrese valores enteros de 0 a 24");
                }

                if (!error3)
                {
                    ht3 = Math.Abs(hs3 - he3);

                    if (ht3 < 4)
                    {
                        pagoDia3 = 0;
                    }
                    else if (ht3 < 6)
                    {
                        pagoDia3 = (ht3 * vh) * 0.90m;
                    }
                    else if (ht3 <= 8)
                    {
                        pagoDia3 = ht3 * vh;
                    }
                    else
                    {
                        int extras = ht3 - 8;
                        pagoDia3 = (8 * vh) + (extras * vh * 1.5m);
                    }
                    decimal salarioSemanal = pagoDia1 + pagoDia2 + pagoDia3;
                    MessageBox.Show(
                        "Horas Día 1: " + ht1 + " ($" + pagoDia1 + ")\n" +
                        "Horas Día 2: " + ht2 + " ($" + pagoDia2 + ")\n" +
                        "Horas Día 3: " + ht3 + " ($" + pagoDia3 + ")\n\n" +
                        "Salario Total Semanal: $" + salarioSemanal);                       
                }
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

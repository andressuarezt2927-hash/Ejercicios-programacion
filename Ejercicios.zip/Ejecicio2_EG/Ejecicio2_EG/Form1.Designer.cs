﻿namespace Ejecicio2_EG
{
    partial class Background
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title_t = new System.Windows.Forms.Label();
            this.Description_t = new System.Windows.Forms.Label();
            this.seg = new System.Windows.Forms.Button();
            this.day_t = new System.Windows.Forms.Label();
            this.sal_t = new System.Windows.Forms.Label();
            this.houren_l = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hoursa_l = new System.Windows.Forms.Label();
            this.horaen_tb = new System.Windows.Forms.TextBox();
            this.horasal_tb = new System.Windows.Forms.TextBox();
            this.valorhora_tb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Title_t
            // 
            this.Title_t.AutoSize = true;
            this.Title_t.Location = new System.Drawing.Point(0, 0);
            this.Title_t.Name = "Title_t";
            this.Title_t.Size = new System.Drawing.Size(133, 20);
            this.Title_t.TabIndex = 0;
            this.Title_t.Text = "Cálculo de salario";
            // 
            // Description_t
            // 
            this.Description_t.AutoSize = true;
            this.Description_t.Location = new System.Drawing.Point(12, 31);
            this.Description_t.Name = "Description_t";
            this.Description_t.Size = new System.Drawing.Size(571, 20);
            this.Description_t.TabIndex = 1;
            this.Description_t.Text = "Ingrese cada uno de los datos una vez ingresados de click en el boton siguiente";
            // 
            // seg
            // 
            this.seg.Location = new System.Drawing.Point(17, 298);
            this.seg.Name = "seg";
            this.seg.Size = new System.Drawing.Size(116, 33);
            this.seg.TabIndex = 2;
            this.seg.Text = "Seguir";
            this.seg.UseVisualStyleBackColor = true;
            this.seg.Click += new System.EventHandler(this.seg_Click);
            // 
            // day_t
            // 
            this.day_t.AutoSize = true;
            this.day_t.Location = new System.Drawing.Point(64, 51);
            this.day_t.Name = "day_t";
            this.day_t.Size = new System.Drawing.Size(46, 20);
            this.day_t.TabIndex = 3;
            this.day_t.Text = "Dia 1";
            // 
            // sal_t
            // 
            this.sal_t.AutoSize = true;
            this.sal_t.Location = new System.Drawing.Point(13, 109);
            this.sal_t.Name = "sal_t";
            this.sal_t.Size = new System.Drawing.Size(246, 20);
            this.sal_t.TabIndex = 4;
            this.sal_t.Text = "Ingrese el valor de hora de salario";
            // 
            // houren_l
            // 
            this.houren_l.AutoSize = true;
            this.houren_l.Location = new System.Drawing.Point(43, 161);
            this.houren_l.Name = "houren_l";
            this.houren_l.Size = new System.Drawing.Size(129, 20);
            this.houren_l.TabIndex = 5;
            this.houren_l.Text = "Hora de entrada:";
            this.houren_l.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(437, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ingrese la hora en formato de 24 horas y sin fracción de hora";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // hoursa_l
            // 
            this.hoursa_l.AutoSize = true;
            this.hoursa_l.Location = new System.Drawing.Point(43, 218);
            this.hoursa_l.Name = "hoursa_l";
            this.hoursa_l.Size = new System.Drawing.Size(119, 20);
            this.hoursa_l.TabIndex = 7;
            this.hoursa_l.Text = "Hora de salida :";
            // 
            // horaen_tb
            // 
            this.horaen_tb.Location = new System.Drawing.Point(274, 161);
            this.horaen_tb.Name = "horaen_tb";
            this.horaen_tb.Size = new System.Drawing.Size(173, 26);
            this.horaen_tb.TabIndex = 8;
            // 
            // horasal_tb
            // 
            this.horasal_tb.Location = new System.Drawing.Point(274, 218);
            this.horasal_tb.Name = "horasal_tb";
            this.horasal_tb.Size = new System.Drawing.Size(173, 26);
            this.horasal_tb.TabIndex = 9;
            // 
            // valorhora_tb
            // 
            this.valorhora_tb.Location = new System.Drawing.Point(274, 109);
            this.valorhora_tb.Name = "valorhora_tb";
            this.valorhora_tb.Size = new System.Drawing.Size(173, 26);
            this.valorhora_tb.TabIndex = 10;
            // 
            // Background
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 343);
            this.Controls.Add(this.valorhora_tb);
            this.Controls.Add(this.horasal_tb);
            this.Controls.Add(this.horaen_tb);
            this.Controls.Add(this.hoursa_l);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.houren_l);
            this.Controls.Add(this.sal_t);
            this.Controls.Add(this.day_t);
            this.Controls.Add(this.seg);
            this.Controls.Add(this.Description_t);
            this.Controls.Add(this.Title_t);
            this.Name = "Background";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title_t;
        private System.Windows.Forms.Label Description_t;
        private System.Windows.Forms.Button seg;
        private System.Windows.Forms.Label day_t;
        private System.Windows.Forms.Label sal_t;
        private System.Windows.Forms.Label houren_l;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label hoursa_l;
        private System.Windows.Forms.TextBox horaen_tb;
        private System.Windows.Forms.TextBox horasal_tb;
        private System.Windows.Forms.TextBox valorhora_tb;
    }
}


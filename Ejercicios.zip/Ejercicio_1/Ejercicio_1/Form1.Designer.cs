﻿namespace Ejercicio_1
{
    partial class Fondo
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.calcular = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.hour_t = new System.Windows.Forms.TextBox();
            this.Description_t = new System.Windows.Forms.TextBox();
            this.Minutes_t = new System.Windows.Forms.TextBox();
            this.seconds_t = new System.Windows.Forms.TextBox();
            this.hour_s = new System.Windows.Forms.TextBox();
            this.minutes = new System.Windows.Forms.TextBox();
            this.seconds = new System.Windows.Forms.TextBox();
            this.Costo_t = new System.Windows.Forms.TextBox();
            this.Costo = new System.Windows.Forms.TextBox();
            this.timeseg_t = new System.Windows.Forms.TextBox();
            this.costost_t = new System.Windows.Forms.TextBox();
            this.time_t = new System.Windows.Forms.TextBox();
            this.textocosto = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Limpiar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // calcular
            // 
            this.calcular.AutoSize = true;
            this.calcular.BackColor = System.Drawing.Color.White;
            this.calcular.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcular.Location = new System.Drawing.Point(12, 472);
            this.calcular.Name = "calcular";
            this.calcular.Size = new System.Drawing.Size(197, 74);
            this.calcular.TabIndex = 0;
            this.calcular.Text = "Calcular";
            this.calcular.UseVisualStyleBackColor = false;
            this.calcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.BackColor = System.Drawing.Color.White;
            this.Title.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Title.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(14, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(267, 39);
            this.Title.TabIndex = 1;
            this.Title.Text = "Cálculo De Costos ";
            this.Title.Click += new System.EventHandler(this.label1_Click);
            // 
            // hour_t
            // 
            this.hour_t.BackColor = System.Drawing.Color.LightGray;
            this.hour_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hour_t.Location = new System.Drawing.Point(45, 178);
            this.hour_t.Name = "hour_t";
            this.hour_t.ReadOnly = true;
            this.hour_t.Size = new System.Drawing.Size(384, 19);
            this.hour_t.TabIndex = 2;
            this.hour_t.Text = "Hora (s)";
            this.hour_t.TextChanged += new System.EventHandler(this.hour_e_TextChanged);
            // 
            // Description_t
            // 
            this.Description_t.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.Description_t.BackColor = System.Drawing.Color.LightGray;
            this.Description_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Description_t.Font = new System.Drawing.Font("Calisto MT", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Description_t.Location = new System.Drawing.Point(14, 95);
            this.Description_t.Multiline = true;
            this.Description_t.Name = "Description_t";
            this.Description_t.ReadOnly = true;
            this.Description_t.Size = new System.Drawing.Size(978, 48);
            this.Description_t.TabIndex = 4;
            this.Description_t.Text = "Ingrese en los siguientes recuadros la información solicitada según corresponda";
            // 
            // Minutes_t
            // 
            this.Minutes_t.BackColor = System.Drawing.Color.LightGray;
            this.Minutes_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Minutes_t.Location = new System.Drawing.Point(45, 229);
            this.Minutes_t.Name = "Minutes_t";
            this.Minutes_t.ReadOnly = true;
            this.Minutes_t.Size = new System.Drawing.Size(384, 19);
            this.Minutes_t.TabIndex = 5;
            this.Minutes_t.Text = "Minuto(s)";
            this.Minutes_t.TextChanged += new System.EventHandler(this.Minutes_e_TextChanged);
            // 
            // seconds_t
            // 
            this.seconds_t.BackColor = System.Drawing.Color.LightGray;
            this.seconds_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.seconds_t.Location = new System.Drawing.Point(45, 285);
            this.seconds_t.Name = "seconds_t";
            this.seconds_t.ReadOnly = true;
            this.seconds_t.Size = new System.Drawing.Size(384, 19);
            this.seconds_t.TabIndex = 6;
            this.seconds_t.Text = "Segundo(s)";
            // 
            // hour_s
            // 
            this.hour_s.Location = new System.Drawing.Point(335, 175);
            this.hour_s.Name = "hour_s";
            this.hour_s.Size = new System.Drawing.Size(185, 26);
            this.hour_s.TabIndex = 7;
            // 
            // minutes
            // 
            this.minutes.Location = new System.Drawing.Point(335, 229);
            this.minutes.Name = "minutes";
            this.minutes.Size = new System.Drawing.Size(185, 26);
            this.minutes.TabIndex = 8;
            // 
            // seconds
            // 
            this.seconds.Location = new System.Drawing.Point(335, 285);
            this.seconds.Name = "seconds";
            this.seconds.Size = new System.Drawing.Size(185, 26);
            this.seconds.TabIndex = 9;
            // 
            // Costo_t
            // 
            this.Costo_t.BackColor = System.Drawing.Color.LightGray;
            this.Costo_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Costo_t.Location = new System.Drawing.Point(45, 332);
            this.Costo_t.Multiline = true;
            this.Costo_t.Name = "Costo_t";
            this.Costo_t.ReadOnly = true;
            this.Costo_t.Size = new System.Drawing.Size(149, 46);
            this.Costo_t.TabIndex = 10;
            this.Costo_t.Text = "Costo por segundo de la operación";
            this.Costo_t.Visible = false;
            // 
            // Costo
            // 
            this.Costo.Location = new System.Drawing.Point(335, 332);
            this.Costo.Name = "Costo";
            this.Costo.Size = new System.Drawing.Size(185, 26);
            this.Costo.TabIndex = 11;
            this.Costo.Visible = false;
            // 
            // timeseg_t
            // 
            this.timeseg_t.BackColor = System.Drawing.Color.LightGray;
            this.timeseg_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.timeseg_t.Location = new System.Drawing.Point(567, 175);
            this.timeseg_t.Multiline = true;
            this.timeseg_t.Name = "timeseg_t";
            this.timeseg_t.ReadOnly = true;
            this.timeseg_t.Size = new System.Drawing.Size(196, 26);
            this.timeseg_t.TabIndex = 12;
            this.timeseg_t.Text = "Tiempo total en segundos ";
            this.timeseg_t.Visible = false;
            this.timeseg_t.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // costost_t
            // 
            this.costost_t.BackColor = System.Drawing.Color.DarkOrange;
            this.costost_t.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.costost_t.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costost_t.Location = new System.Drawing.Point(567, 376);
            this.costost_t.Multiline = true;
            this.costost_t.Name = "costost_t";
            this.costost_t.ReadOnly = true;
            this.costost_t.Size = new System.Drawing.Size(496, 66);
            this.costost_t.TabIndex = 13;
            this.costost_t.Text = "Costo total de la operación ";
            this.costost_t.Visible = false;
            this.costost_t.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // time_t
            // 
            this.time_t.Location = new System.Drawing.Point(756, 175);
            this.time_t.Name = "time_t";
            this.time_t.Size = new System.Drawing.Size(392, 26);
            this.time_t.TabIndex = 14;
            this.time_t.Visible = false;
            // 
            // textocosto
            // 
            this.textocosto.Location = new System.Drawing.Point(596, 433);
            this.textocosto.Name = "textocosto";
            this.textocosto.Size = new System.Drawing.Size(459, 26);
            this.textocosto.TabIndex = 15;
            this.textocosto.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkOrange;
            this.pictureBox1.Location = new System.Drawing.Point(555, 359);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(521, 141);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Limpiar
            // 
            this.Limpiar.AutoSize = true;
            this.Limpiar.BackColor = System.Drawing.Color.White;
            this.Limpiar.Font = new System.Drawing.Font("Elephant", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Limpiar.Location = new System.Drawing.Point(12, 472);
            this.Limpiar.Name = "Limpiar";
            this.Limpiar.Size = new System.Drawing.Size(197, 74);
            this.Limpiar.TabIndex = 17;
            this.Limpiar.Text = "Limpiar";
            this.Limpiar.UseVisualStyleBackColor = false;
            this.Limpiar.Visible = false;
            this.Limpiar.Click += new System.EventHandler(this.Limpiar_Click);
            // 
            // Fondo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1177, 576);
            this.Controls.Add(this.Limpiar);
            this.Controls.Add(this.textocosto);
            this.Controls.Add(this.time_t);
            this.Controls.Add(this.costost_t);
            this.Controls.Add(this.timeseg_t);
            this.Controls.Add(this.Costo);
            this.Controls.Add(this.Costo_t);
            this.Controls.Add(this.seconds);
            this.Controls.Add(this.minutes);
            this.Controls.Add(this.hour_s);
            this.Controls.Add(this.seconds_t);
            this.Controls.Add(this.Minutes_t);
            this.Controls.Add(this.Description_t);
            this.Controls.Add(this.hour_t);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.calcular);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Fondo";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calcular;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.TextBox hour_t;
        private System.Windows.Forms.TextBox Description_t;
        private System.Windows.Forms.TextBox Minutes_t;
        private System.Windows.Forms.TextBox seconds_t;
        private System.Windows.Forms.TextBox hour_s;
        private System.Windows.Forms.TextBox minutes;
        private System.Windows.Forms.TextBox seconds;
        private System.Windows.Forms.TextBox Costo_t;
        private System.Windows.Forms.TextBox Costo;
        private System.Windows.Forms.TextBox timeseg_t;
        private System.Windows.Forms.TextBox costost_t;
        private System.Windows.Forms.TextBox time_t;
        private System.Windows.Forms.TextBox textocosto;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Limpiar;
    }
}


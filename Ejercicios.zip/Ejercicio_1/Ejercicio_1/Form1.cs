﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejercicio_1
{
    public partial class Fondo : Form
    {
        public Fondo()
        {
            InitializeComponent();
        }
        private string originalDesc = "";
        private string originalHourT = "";
        private string originalMinT = "";
        private string originalSecT = "";

        private void button1_Click(object sender, EventArgs e)
        {
            bool hayerror = false;
            decimal horas = 0;
            decimal minutos = 0; 
            decimal segundos = 0;
            // leer todas las var
            if (int.TryParse(hour_s.Text, out int hour_e))
            {
                if (hour_e >= 0)
                {
                    horas = hour_e;
                }
                else 
                {
                    hayerror = true;
                    MessageBox.Show("Por favor ingrese números enteros positivos en el campo de horas");
                }
            }
            else
            {
                MessageBox.Show("Por favor para la hora ingrese solo números enteros válidos");
                hayerror = true;
            }
            if (int.TryParse(minutes.Text, out int minutes_e))
            {
                if (minutes_e > 59 || minutes_e <0)
                {
                    MessageBox.Show("Por favor para los minutos ingrese numeros enteros entre 0 y 59");
                    hayerror = true;
                }
                else
                {
                    minutos = minutes_e;
                }

            }
            else
            {
                MessageBox.Show("Por favor para los minutos ingrese solo números enteros válidos");
                hayerror = true;
            }
            if (int.TryParse(seconds.Text, out int seconds_e))
            {
                if (seconds_e > 59 || seconds_e <0)
                {
                    MessageBox.Show("Por favor para los segundos ingrese numeros enteros entre 0 y 59");
                    hayerror = true;
                }
                else
                {
                     segundos = seconds_e;
                }
            }
            else
            {
                MessageBox.Show("Por favor para los segundos ingrese solo números enteros válidos");
                hayerror = true;
            }

            // Aqui ya se leyeron todas las variables 
            if (!hayerror)
            {
                originalDesc = Description_t.Text;
                originalHourT = hour_t.Text;
                originalMinT = Minutes_t.Text;
                originalSecT = seconds_t.Text;
                // Cambiar los textos y propiedades 
                Description_t.Text = ("Después de realizados los calculos los resultados obtenidos fueron :");
                    hour_t.Text = ("Las horas totales utilizadas fueron : ");
                    hour_s.ReadOnly = true;
                    Minutes_t.Text = ("Los minutos totales utilizados fueron: ");
                    minutes.ReadOnly = true;
                    seconds_t.Text = ("Los segundos utilizados fueron : ");
                    seconds.ReadOnly = true;
                    Costo_t.Visible = true;
                    Costo.Text = ("25");
                    Costo.Visible = true;
                    Costo.ReadOnly = true;
                // Operaciones 
                decimal hour_seg = horas * 3600;
                decimal minutes_seg = minutos * 60;
                decimal totalseg = hour_seg + minutes_seg + segundos;
                decimal costototal = totalseg * 25;
                time_t.Text =Convert.ToString(totalseg);
                time_t.Visible=true;
                time_t.ReadOnly=true;
                textocosto.Text = Convert.ToString(costototal);
                textocosto.Visible = true;
                textocosto.ReadOnly = true;
                costost_t.Visible = true;
                timeseg_t.Visible = true;
                pictureBox1.Visible = true;
                Limpiar.Visible = true;
                calcular.Visible = false;
                Limpiar.Focus();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void hour_e_TextChanged(object sender, EventArgs e)
        {

        }

        private void Minutes_e_TextChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Limpiar_Click(object sender, EventArgs e)
        {
            Description_t.Text = originalDesc;
            hour_t.Text = originalHourT;
            Minutes_t.Text = originalMinT;
            seconds_t.Text = originalSecT;
            hour_s.ReadOnly = false;
            minutes.ReadOnly = false;
            seconds.ReadOnly = false;
            hour_s.Clear();
            minutes.Clear();
            seconds.Clear();
            Costo_t.Visible = false;
            Costo.Visible = false;
            time_t.Visible = false;
            textocosto.Visible = false;
            costost_t.Visible = false;
            timeseg_t.Visible = false;
            pictureBox1.Visible = false;
            Limpiar.Visible = false;
            calcular.Visible = true;
        }
    }
}

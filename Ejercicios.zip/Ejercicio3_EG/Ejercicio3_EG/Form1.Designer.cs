﻿namespace Ejercicio3_EG
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.kw_l = new System.Windows.Forms.Label();
            this.est_l = new System.Windows.Forms.Label();
            this.calcular = new System.Windows.Forms.Button();
            this.kw_tb = new System.Windows.Forms.TextBox();
            this.est_tb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(3, 0);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(94, 20);
            this.Title.TabIndex = 0;
            this.Title.Text = "Factura Luz";
            // 
            // kw_l
            // 
            this.kw_l.AutoSize = true;
            this.kw_l.Location = new System.Drawing.Point(100, 103);
            this.kw_l.Name = "kw_l";
            this.kw_l.Size = new System.Drawing.Size(102, 20);
            this.kw_l.TabIndex = 1;
            this.kw_l.Text = "Consumo Kw";
            // 
            // est_l
            // 
            this.est_l.AutoSize = true;
            this.est_l.Location = new System.Drawing.Point(100, 163);
            this.est_l.Name = "est_l";
            this.est_l.Size = new System.Drawing.Size(61, 20);
            this.est_l.TabIndex = 2;
            this.est_l.Text = "Estrato";
            // 
            // calcular
            // 
            this.calcular.Location = new System.Drawing.Point(25, 368);
            this.calcular.Name = "calcular";
            this.calcular.Size = new System.Drawing.Size(136, 51);
            this.calcular.TabIndex = 3;
            this.calcular.Text = "Calcular";
            this.calcular.UseVisualStyleBackColor = true;
            this.calcular.Click += new System.EventHandler(this.calcular_Click);
            // 
            // kw_tb
            // 
            this.kw_tb.Location = new System.Drawing.Point(240, 95);
            this.kw_tb.Name = "kw_tb";
            this.kw_tb.Size = new System.Drawing.Size(172, 26);
            this.kw_tb.TabIndex = 4;
            // 
            // est_tb
            // 
            this.est_tb.Location = new System.Drawing.Point(240, 157);
            this.est_tb.Name = "est_tb";
            this.est_tb.Size = new System.Drawing.Size(172, 26);
            this.est_tb.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.est_tb);
            this.Controls.Add(this.kw_tb);
            this.Controls.Add(this.calcular);
            this.Controls.Add(this.est_l);
            this.Controls.Add(this.kw_l);
            this.Controls.Add(this.Title);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label kw_l;
        private System.Windows.Forms.Label est_l;
        private System.Windows.Forms.Button calcular;
        private System.Windows.Forms.TextBox kw_tb;
        private System.Windows.Forms.TextBox est_tb;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3_EG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcular_Click(object sender, EventArgs e)
        {
            {
                bool error = false;
                decimal kw = 0;
                int est = 0;

                if (decimal.TryParse(kw_tb.Text, out decimal kw_e))
                {
                    if (kw_e >= 0)
                    {
                        kw = kw_e;
                    }
                    else
                    {
                        error = true;
                        MessageBox.Show("Por favor ingrese una cantidad de kilovatios mayor o igual a 0");
                    }
                }
                else
                {
                    error = true;
                    MessageBox.Show("Por favor para los kilovatios ingrese valores numéricos válidos");
                }

                if (int.TryParse(est_tb.Text, out int est_e))
                {
                    if (est_e >= 1 && est_e <= 6)
                    {
                        est = est_e;
                    }
                    else
                    {
                        error = true;
                        MessageBox.Show("Por favor ingrese un estrato válido (entre 1 y 6)");
                    }
                }
                else
                {
                    error = true;
                    MessageBox.Show("Por favor para el estrato ingrese números enteros válidos");
                }

                if (!error)
                {
                    decimal precioBase = 0;
                    decimal precioExtra = 0;
                    decimal porcentajeImpuesto = 0;

                    if (est == 1 || est == 2)
                    {
                        precioBase = 14;
                        precioExtra = 17;
                        porcentajeImpuesto = 0.03m;
                    }
                    else if (est == 3)
                    {
                        precioBase = 18;
                        precioExtra = 23;
                        porcentajeImpuesto = 0.04m;
                    }
                    else if (est == 4)
                    {
                        precioBase = 21;
                        precioExtra = 27;
                        porcentajeImpuesto = 0.05m;
                    }
                    else if (est == 5 || est == 6)
                    {
                        precioBase = 28;
                        precioExtra = 35;
                        porcentajeImpuesto = 0.06m;
                    }

                    decimal costoFactura = 0;
                    if (kw <= 300)
                    {
                        costoFactura = kw * precioBase;
                    }
                    else
                    {
                        decimal kwExtras = kw - 300;
                        costoFactura = (300 * precioBase) + (kwExtras * precioExtra);
                    }
                    decimal valorImpuesto = costoFactura * porcentajeImpuesto;
                    decimal totalPagar = costoFactura + valorImpuesto;
                    MessageBox.Show(
                        "Costo de la factura: $" + costoFactura + "\n" +
                        "Impuesto: $" + valorImpuesto + "\n" +
                        "Total a pagar: $" + totalPagar
                    );
                }
            }
        }
    }
}
